const server = 'https://jsonplaceholder.typicode.com/posts'

const sendData = (data, callBack, falseCallBack, form) => {
    const request = new XMLHttpRequest();
    request.open('POST', server);

    request.addEventListener('readystatechange', () => {
        if (request.readyState !== 4) return;
        if (request.status === 200 || request.status === 201) {
            const response = JSON.parse(request.responseText)
            callBack(response.id);

            form.querySelector('.button').setAttribute("disabled", "disabled")
            setTimeout(() => blockElems(form), 5000)
        } else {
            falseCallBack(request.status)
            throw new Error(request.status)
        }
    });
    request.send(data);
}

const formElems = document.querySelectorAll('.form');
const formHandler = (form) => {

    const smallElem = document.createElement('small');

    form.addEventListener('submit', (e) => {
        e.preventDefault();
        const data = {};
        for (const { name, value, localName } of form.elements) {
            if (name && value && value.trim().length !== 0) {
                data[name] = value
            } else {
                if (localName !== "button") {
                    smallElem.textContent = 'Заполните поля!!!';
                    // smallElem.id = "small";
                    smallElem.style.color = 'red'
                    form.append(smallElem);
                    throw new Error
                }
            }
        }

        sendData(JSON.stringify(data), (id) => {
            smallElem.innerHTML = 'Номер вашей заявки:<br>' + id;
            smallElem.style.color = 'green';
            form.append(smallElem);

        }, (err) => {
            smallElem.textContent = 'Технические неполадки, ожидайте: ' + err;
            smallElem.style.color = 'red'
            form.append(smallElem);
        }, form);
        form.reset();
    })
}

const blockElems = (form) => {
    form.querySelector('.button').removeAttribute("disabled")
    document.querySelector('small').remove()
}

formElems.forEach(formHandler)